#
# Cookbook:: wordpress
# Recipe:: wpcli
#
# Copyright:: 2023, The Authors, All Rights Reserved.


remote_file '/usr/local/bin/wp' do
  source 'https://raw.githubusercontent.com/wp-cli/builds/gh-pages/phar/wp-cli.phar'
  owner 'vagrant'
  group 'vagrant'
  mode '0755'
  action :create
end


execute 'Creamos el usuario' do
  command "wp core install --url=localhost:8090  --title='Equipo 1002C WordPress Instalacion'  --locale=es_SV --admin_name=wordpress --admin_password=123 --admin_email=equipo_1002C@hotmail.com --allow-root --path='/var/www/html'"
end

execute 'restart apache' do
  command '/usr/sbin/apachectl configtest && /usr/sbin/service apache2 reload'
end