#
# Cookbook:: wordpress
# Recipe:: php
#
# Copyright:: 2023, The Authors, All Rights Reserved.
execute 'instalar dependencias de php' do
  command 'sudo apt install ca-certificates apt-transport-https software-properties-common -y'
end

execute 'Agregar repositorio defaul' do
  command 'sudo add-apt-repository -y ppa:ondrej/php'
end



# Instalamos PHP 7.4 y extensiones necesarias
package 'php7.4' do
  action :install
end

package 'php7.4-cli' do
  action :install
end

package 'php7.4-fpm' do
  action :install
end

package 'php7.4-common' do
  action :install
end

package 'php7.4-imap' do
  action :install
end

package 'php7.4-redis' do
  action :install
end

package 'php7.4-xml' do
  action :install
end

package 'php7.4-zip' do
  action :install
end

package 'php7.4-mbstring' do
  action :install
end

package 'php7.4-mysql' do
  action :install
end

# Reiniciamos el servicio de PHP-FPM
service 'php7.4-fpm' do
  action :restart
end

execute 'Habilitar los servicios de php' do
  command 'a2enmod proxy_fcgi setenvif && a2enconf php7.4-fpm && a2enmod php7.4'
end

execute 'reiniciando apache' do
  command '/usr/sbin/apachectl configtest && /usr/sbin/service apache2 reload'
end
