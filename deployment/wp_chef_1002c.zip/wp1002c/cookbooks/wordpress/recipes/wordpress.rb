#
# Cookbook:: wordpress
# Recipe:: wordpress
#
# Copyright:: 2023, The Authors, All Rights Reserved.

# Instalamos Wordpress
remote_file '/tmp/latest.tar.gz' do
  source 'https://wordpress.org/latest.tar.gz'
end

execute 'extract_wordpress' do
  command 'tar xzf /tmp/latest.tar.gz -C /var/www/html --strip-components=1'
end

template '/var/www/html/wp-config.php' do
  source 'wp-config.php.erb'
end

execute 'change owner' do
  command 'chown -R www-data:www-data /var/www/html'
end

execute 'change permissions' do
  command 'chmod -R 775 /var/www/html'
end

execute 'restart apache' do
  command '/usr/sbin/apachectl configtest && /usr/sbin/service apache2 reload'
end

