#
# Cookbook:: wordpress
# Recipe:: mysql
#
# Copyright:: 2023, The Authors, All Rights Reserved.
# Instalar MySQL
package 'mysql-server' do
  action :install
end

package 'libapache2-mod-php7.4' do
  action :install
end

package 'php-mysql' do
  action :install
end

execute 'Reiniciar apache2' do
  command '/usr/sbin/apachectl configtest && /usr/sbin/service apache2 reload'
end

# Habilitar servicio MySQL y configurarlo para que se inicie en el arranque
service 'mysql' do
  action [:enable, :start]
end


execute 'Reiniciar mysql' do
  command '/usr/sbin/service mysql reload'
end


# Crear la base de datos 'wordpress'
execute 'create-wordpress-db' do
  command 'mysql -uroot -e "CREATE DATABASE wordpress;"'
  sensitive true
  not_if 'mysql -uroot -e "SHOW DATABASES;" | grep -q wordpress'
end

#Aqui creamos el user llamado wordpress
script 'password' do
  interpreter 'bash'
  user 'root'
  cwd '/home/vagrant'
  code <<-EOH
    sudo mysql -uroot -e 'CREATE USER wordpress@localhost IDENTIFIED BY "'123'";'
  EOH
end


# damos los permisos al usuario 'wordpress'
execute 'privileges-wordpress-db' do
  command 'mysql -uroot -e "GRANT ALL PRIVILEGES ON *.* TO wordpress@localhost;"'
end

