#
# Cookbook:: wordpress
# Recipe:: apache
#
# Copyright:: 2023, The Authors, All Rights Reserved.

package 'apache2' do
  action :install
end

execute 'Borrando archivo default' do
  command 'sudo rm -rf /etc/apache2/sites-enabled/000-default.conf'
end

execute 'creamos el vagrant.conf' do
  command 'sudo touch /etc/apache2/sites-available/vagrant.conf'
end

template '/etc/apache2/sites-available/vagrant.conf' do
  source 'vh.conf.erb'
end


execute 'creamos el enlace simbolico' do
  command 'sudo ln -s /etc/apache2/sites-available/vagrant.conf /etc/apache2/sites-enabled/vagrant.conf'
end


execute 'Borrando archivo index' do
  command 'sudo rm -rf /var/www/html/index.html'
end


service 'apache2' do
  action [ :enable, :start ]
end

execute 'reiniciando apache' do
  command '/usr/sbin/apachectl configtest && /usr/sbin/service apache2 reload'
end