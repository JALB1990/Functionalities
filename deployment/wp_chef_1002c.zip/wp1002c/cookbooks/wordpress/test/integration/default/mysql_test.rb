# Chef InSpec test for recipe wordpress::mysql

# The Chef InSpec reference, with examples and extensive documentation, can be
# found at https://docs.chef.io/inspec/resources/

describe package('mysql-server') do
  it { should be_installed }
end


describe port(33060) do
  it { should be_listening }
end


sql = mysql_session('wordpress','123')

describe sql.query('show databases like \'wordpress\';') do
  its('output') { should match(/wordpress/) }
end