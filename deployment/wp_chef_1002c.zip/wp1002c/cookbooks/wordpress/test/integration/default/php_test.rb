# Chef InSpec test for recipe wordpress::php

# The Chef InSpec reference, with examples and extensive documentation, can be
# found at https://docs.chef.io/inspec/resources/

# This is an example test, replace it with your own test.
#describe port(80), :skip do
#  it { should_not be_listening }
#end


describe package('libapache2-mod-php7.4') do
  it { should be_installed }
end


describe package('php-mysql') do
  it { should be_installed }
end