# Chef InSpec test for recipe wordpress::wordpress

# The Chef InSpec reference, with examples and extensive documentation, can be
# found at https://docs.chef.io/inspec/resources/

describe port(8090) do
  it { should_not be_listening }
end


describe file('/var/www/html/wp-config.php') do
  it { should exist }
end

describe file('/var/www/html') do 
    its('owner') { should eq 'www-data' }
end

describe file('/var/www/html') do     
    its('mode') { should cmp '0775' }
end

