# Chef InSpec test for recipe wordpress::apache

# The Chef InSpec reference, with examples and extensive documentation, can be
# found at https://docs.chef.io/inspec/resources/

# This is an example test, replace it with your own test.

describe package('apache2') do
  it { should be_installed }
end

describe port(80) do
  it { should be_listening }
end


describe file('/var/www/html') do 
      it { should exist }
end

