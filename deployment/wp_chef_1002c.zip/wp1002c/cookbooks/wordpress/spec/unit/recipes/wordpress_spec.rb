#
# Cookbook:: wordpress
# Spec:: wordpress
#
# Copyright:: 2023, The Authors, All Rights Reserved.

require 'chefspec'

describe 'wordpress::wordpress' do

  let(:chef_run) do

  runner = ChefSpec::SoloRunner.new(platform: 'ubuntu', version: '20.04')
  runner.converge(described_recipe)
  end


  it 'descarga el archivo remoto latest.tar.gz correctamente' do
    expect(chef_run).to create_remote_file('/tmp/latest.tar.gz')
      .with_source('https://wordpress.org/latest.tar.gz')
  end

  it 'extrae el contenido del archivo tar correctamente' do
    expect(chef_run).to run_execute('extract_wordpress')
      .with(command: 'tar xzf /tmp/latest.tar.gz -C /var/www/html --strip-components=1')
  end

  it 'crea el archivo wp-config.php correctamente' do
    expect(chef_run).to create_template('/var/www/html/wp-config.php')
      .with_source('wp-config.php.erb')
  end

  it 'cambia el propietario del directorio /var/www/html correctamente' do
    expect(chef_run).to run_execute('change owner')
      .with(command: 'chown -R www-data:www-data /var/www/html')
  end

  it 'cambia los permisos del directorio /var/www/html correctamente' do
    expect(chef_run).to run_execute('change permissions')
      .with(command: 'chmod -R 775 /var/www/html')
  end

  it 'reinicia Apache correctamente' do
    expect(chef_run).to run_execute('restart apache')
      .with(command: '/usr/sbin/apachectl configtest && /usr/sbin/service apache2 reload')
  end
end

