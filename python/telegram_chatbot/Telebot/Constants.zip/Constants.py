API_KEY = '5084500279:AAEI4NnFQqy3ibV0O8QqkShbCcXXgkpB2ZE'
url_report = "https://quadgraphics--tst2.custhelp.com/services/rest/connect/v1.3/analyticsReportResults"
url_inc = "https://quadgraphics--tst2.custhelp.com/services/rest/connect/v1.3/incidents"
headers = {'Authorization':'Basic SkFMQUdVTkFCQVJCOlBhc3N3b3JkMQ=='}